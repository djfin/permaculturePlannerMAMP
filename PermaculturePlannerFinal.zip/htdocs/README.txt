Welcome to your Permaculture Planner Application. 
Please set up a MySQL database named 'permacultureProject'. Then create a MySQL user
named 'permacultureUser' with the password 'mypass'. Once your database is set up
please navigate to the setup.php page and your database will automatically
be set up. You are now ready to run the application. Navigate to the 
index.php page and enjoy!

