<?php
require_once 'converterDB.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {
   $usVal = $_POST['usVal'];
   ConverterDB::getInstance()->insert_money_item($usVal);
   $result= ConverterDB::getInstance()->get_foreign_currency_by_us_currency($usVal);
   $row = mysqli_fetch_array($result);
   $mexVal=$row['mexPesoValue'];
   $canDollarValue=$row['canDollarValue'];
   echo($usVal." US Dollars =".$mexVal." Mexican Pesos and ".$canDollarValue." Canadian Dollars");
   
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title> NAFTA Currency Converter </title>
    </head>
    <body>
       
        <form name="convertMoney" action="converterApp.php" method="POST" >
            Enter the US Dollar amount you want to convert: <input type="text" name="usVal"/>
        </form>
        <form name="conversionHistory" action="conversionHistory.php">
            <input type="submit" name="conversionHist" value="View Converson History"/>
        </form>
        <?php
        
        ?>
    </body>
</html>
