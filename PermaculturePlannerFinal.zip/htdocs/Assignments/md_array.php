<?php 
	$products = array(
	'sleeping_bag' => array(
		'kelty' => "Kelty Twenty Degree Sleeping Bag",
		'marmot' => "Marmot Zero Degree Sleeping Bag",
		'north_face' => "North Face Zero Degree Sleeping Bag"),
	'sleeping_pad' => array(
		'therma_rest' => "ThermaRest Sleeping Pad",
		'foam' => "Foam Sleeping Pad"),
	'tent' => array(
		'four_man' => array(
			'mountain_smith' => "Four Man MountainSmith tent",
			'rei' => "Four  Man REI tent"),
		'three_man' => array(
			'alps_mountaineering' => "Three Man Alps Mountaineering"),
		'two_man' => array(
			'rei' => "Two Man REI tent",
			'mountain_smith'=> "Two Man MountainSmith tent")
            )
	);
	echo "<pre>";
	print_r($products);
        foreach($products as $section => $items){
            foreach($items as $key => $value){
                if(!is_string($value)){
                    foreach($value as $subVal => $valItem){
                        echo "$section:\t$key:\t$subVal\t($valItem)<br>";
                    }
                }else{
                    echo "$section:\t$key\t($value)<br>";
                }
            }
        }
?>
		

	
