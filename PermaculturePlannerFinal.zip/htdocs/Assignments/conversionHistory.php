<?php
require_once 'converterDB.php';
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Conversion History</title>
    </head>
    <body>
        Conversion History </br>
        <table border="black">
            <tr>
                <th>US Currency Value</th>
                <th>Mexican Peso Value</th>
                <th>Canadian Dollar Value</th>
            </tr>
            <?php
            $result = ConverterDB::getInstance()->get_conversion_table();
            while ($row = mysqli_fetch_array($result)){
                echo "<tr><td>" . htmlentities($row['usDollarValue']) . "</td>";
                echo "<td>" . htmlentities($row['mexPesoValue']) . "</td>";
                echo "<td>".htmlentities($row['canDollarValue'])."</td></tr>";
            }
            ?>
        </table>
        <form name="back" action="converterApp.php">
            <input type="submit" name="back" value="Back to converter"/>
        </form>
    </body>
</html>
